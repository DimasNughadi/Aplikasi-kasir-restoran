package Controller;

import Model.Connector;
import Model.Meja;
import view.FrmMeja;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class MejaController implements ActionListener, MouseListener{
    private Meja data;
    private FrmMeja frm;
    
    public MejaController(Meja data, FrmMeja frm){
        this.data = data;
        this.frm = frm;
        this.frm.jButton1.addActionListener(this);
        this.frm.jButton2.addActionListener(this);
        this.frm.jButton3.addActionListener(this);
        this.frm.jButton4.addActionListener(this);
        this.frm.jButton5.addActionListener(this);
        this.frm.jButton6.addActionListener(this);
        this.frm.jTable1.addMouseListener(this);
    }
    
    public void KosongkanFormMeja(){
        frm.jTextField1.setEditable(true);
        frm.jTextField1.setText(null);
        frm.jTextField2.setText(null);
    }
    
    public void TampilDataMeja(){
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID MEJA");
        model.addColumn("KAPASITAS");
        model.addColumn("STATUS");;
        
        try{
            String sql = "SELECT * FROM meja";
            java.sql.Connection conn = Connector.configDB();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet res = stm.executeQuery(sql);
            
            while (res.next()){
                model.addRow(new Object[]{
                res.getString(1),
                res.getString(2),
                res.getString(3)});
            }
            frm.jTable1.setModel(model);
            
            
        }
        catch(SQLException e){
            System.out.println("Error "+e.getMessage());
        }
    }
    
    @Override
    public void actionPerformed(ActionEvent ae) {
        if(ae.getSource()==frm.jButton2){
            KosongkanFormMeja();
            
        }else if(ae.getSource()==frm.jButton1){
            data.setId(frm.jTextField1.getText());
            try{
                if(data.ResetMeja(data)){
                    JOptionPane.showMessageDialog(null, "Reset Data Sukses");
                    KosongkanFormMeja();
                    TampilDataMeja();
                }
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null, ex);
            }
            
        }else if(ae.getSource()==frm.jButton3){
            data.setId(frm.jTextField1.getText());
            data.setKapasitas(frm.jTextField2.getText());
            try{
                if(data.SimpanMeja(data)){
                    JOptionPane.showMessageDialog(null, "Simpan Data Sukses");
                    KosongkanFormMeja();
                    TampilDataMeja();
                }
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null, ex);
            }
            
        }else if(ae.getSource()==frm.jButton4){
            data.setId(frm.jTextField1.getText());
            data.setKapasitas(frm.jTextField2.getText());
            try{
                if(data.UpdateMeja(data)){
                    JOptionPane.showMessageDialog(null, "Update Data Sukses");
                    KosongkanFormMeja();
                    TampilDataMeja();
                }
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null, ex);
            }
            
        }else if (ae.getSource()==frm.jButton5){
            data.setId(frm.jTextField1.getText());
            try{
                if(data.HapusMeja(data)){
                    JOptionPane.showMessageDialog(null, "Hapus Data Sukses");
                    KosongkanFormMeja();
                    TampilDataMeja();
                }
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null, ex);
            }
        }else if (ae.getSource()==frm.jButton6){
            frm.dispose();
        }
    }

    @Override
    public void mouseClicked(MouseEvent me) {
        if(me.getSource()==frm.jTable1){
            frm.jTextField1.setEditable(false);
            
            int baris = frm.jTable1.rowAtPoint(me.getPoint());
            String id = frm.jTable1.getValueAt(baris, 0).toString();
            frm.jTextField1.setText(id);
            String kategori = frm.jTable1.getValueAt(baris, 1).toString();
            frm.jTextField2.setText(kategori);
        }
    }

    @Override
    public void mousePressed(MouseEvent me) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseReleased(MouseEvent me) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseEntered(MouseEvent me) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseExited(MouseEvent me) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
