package Model;

public class user extends Connector{
    private String username;
    private String password;
    private String level;
    
    public String getUsername(){
        return username;
    }
    public void setUsername(String username){
        this.username = username;
    }
    
    public String getPass(){
        return password;
    }
    public void setPass(String password){
        this.password = password;
    }
    
    public String setLevel(){
        return level;
    }
    public void setLevel(String level){
        this.level = level;
    }
    
}
