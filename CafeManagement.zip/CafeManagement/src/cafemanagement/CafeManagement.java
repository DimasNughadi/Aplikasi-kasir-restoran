package cafemanagement;

import Controller.LoginController;
import Model.user;
import view.FrmLogin;

public class CafeManagement {

    public static void main(String[] args) {
        user data = new user();
        FrmLogin frm = new FrmLogin();
        LoginController ctrl = new LoginController(data, frm);
        frm.setVisible(true);  
    }
    
}
