package Model;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Transaksi extends Connector{
    private String id_transaksi;
    private String jml_pesan;
    private String hargatotal;
    private String hargatotalfinal;
    private String bayar;
    private String kembalian;
    private String status;
    private String customer;
    
    
    public void setIdT(String id_transaksi){
        this.id_transaksi = id_transaksi;
    }
    public String getIdT(){
        return id_transaksi;
    }
    
    public void setJmlPesan(String jml_pesan){
        this.jml_pesan = jml_pesan;
    }
    public String getJmlPesan(){
        return jml_pesan;
    }
    
    public void setHargaT(String hargatotal){
        this.hargatotal = hargatotal;
    }
    public String getHargaT(){
        return hargatotal;
    }
    
    public void setBayar(String bayar){
        this.bayar = bayar;
    }
    public String getBayar(){
        return bayar;
    }
    
    public void setKembalian(String kembalian){
        this.kembalian = kembalian;
    }
    public String getKembalian(){
        return kembalian;
    }
    
    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return status;
    }
    
    public void setCus(String customer){
        this.customer = customer;
    }
    public String getCus(){
        return customer;
    }
    
    public void setHargaF(String hargatotalfinal){
        this.hargatotalfinal = hargatotalfinal;
    }
    public String getHargaF(){
        return hargatotalfinal;
    }
    
    public boolean SimpanTransaksi(Transaksi data, Meja data2, Menu data3) throws SQLException{
        PreparedStatement pstm = null;
        PreparedStatement pstm2 = null;
        Connection conn = (Connection)Connector.configDB();
        
        String sql = "INSERT INTO Transaksi (id_transaksi, id_meja, id_menu, harga, jml_pesan, hargatotal,"
                + "customer)"
                + "VALUES (?,?,?,?,?,?,?)";
        String sql2 = "UPDATE meja set status = 'penuh' WHERE id_meja =?";
        
        try{
            pstm = conn.prepareStatement(sql);
            pstm2 = conn.prepareStatement(sql2);
            pstm.setString(1, data.getIdT());
            pstm.setString(2, data2.getId());
            pstm.setString(3, data3.getId());
            pstm.setString(4, data3.getHarga());
            pstm.setString(5, data.getJmlPesan());
            pstm.setString(6, data.getHargaT());
            pstm.setString(7, data.getCus());
            pstm2.setString(1, data2.getId());
            pstm.execute();
            pstm2.execute();
            return true;
        }catch(HeadlessException | SQLException e){
            System.out.println(e);
            return false;
        }
    }
    
    public boolean UpdateTransaksi(Transaksi data, Meja data2, Menu data3) throws SQLException{
        PreparedStatement pstm = null;
        Connection conn = (Connection)Connector.configDB();
        
        String sql = "UPDATE transaksi SET id_transaksi=?, id_meja=?, id_menu=?, harga=?, jml_pesan=?,"
                + "hargatotal=?, customer=? "
                + "WHERE id_transaksi=?";
        
        try{
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, data.getIdT());
            pstm.setString(2, data2.getId());
            pstm.setString(3, data3.getId());
            pstm.setString(4, data3.getHarga());
            pstm.setString(5, data.getJmlPesan());
            pstm.setString(6, data.getHargaT());
            pstm.setString(7, data.getCus());
            pstm.setString(8, data.getIdT());
            pstm.execute();
            return true;
        }catch(HeadlessException | SQLException e){
            System.out.println(e);
            return false;
        }
    }
    
    public boolean HapusTransaksi(Transaksi data, Menu data3) throws SQLException{
        PreparedStatement pstm = null;
        Connection conn = (Connection)Connector.configDB();
        
        String sql = "DELETE FROM transaksi WHERE id_transaksi=? and id_menu=?";
        
        try{
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, data.getIdT());
            pstm.setString(2, data3.getId());
            pstm.execute();
            return true;
        }catch(HeadlessException | SQLException e){
            System.out.println(e);
            return false;
        }
    }

    public boolean HapusSemua(Transaksi data) throws SQLException{
        PreparedStatement pstm = null;
        Connection conn = (Connection)Connector.configDB();
        
        String sql = "DELETE FROM transaksi WHERE id_transaksi=? and customer=?";
        
        try{
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, data.getIdT());
            pstm.setString(2, data.getCus());
            pstm.execute();
            return true;
        }catch(HeadlessException | SQLException e){
            System.out.println(e);
            return false;
        }
    }
    
}
