package Controller;

import Model.Connector;
import Model.Menu;
import view.FrmMenu;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class MenuController implements ActionListener, MouseListener{
    private Menu data;
    private FrmMenu frm;
    
    public MenuController(Menu data, FrmMenu frm){
        this.data = data;
        this.frm = frm;
        this.frm.jButton1.addActionListener(this);
        this.frm.jButton2.addActionListener(this);
        this.frm.jButton3.addActionListener(this);
        this.frm.jButton4.addActionListener(this);
        this.frm.jButton5.addActionListener(this);
        this.frm.jButton6.addActionListener(this);
        this.frm.jButton7.addActionListener(this);
        this.frm.jButton8.addActionListener(this);
        this.frm.jTable1.addMouseListener(this);
    }
    
    public void KosongkanFormMenu(){
        frm.jTextField1.setEditable(true);
        frm.jTextField1.setText(null);
        frm.jTextField2.setText(null);
        frm.jComboBox1.setSelectedIndex(0);
        frm.jComboBox2.setSelectedIndex(0);
        frm.jTextField5.setText(null);
    }
    
    public void TampilDataMenu(){
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID MENU");
        model.addColumn("NAMA");
        model.addColumn("JENIS");
        model.addColumn("KATEGORI");
        model.addColumn("HARGA");
        
        try{
            String sql = "SELECT * FROM menu";
            java.sql.Connection conn = Connector.configDB();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet res = stm.executeQuery(sql);
            
            while (res.next()){
                model.addRow(new Object[]{
                res.getString(1),
                res.getString(2),
                res.getString(3),
                res.getString(4),
                res.getString(5)});
            }
            frm.jTable1.setModel(model);
            
        }
        catch(SQLException e){
            System.out.println("Error "+e.getMessage());
        }
    }
    
    public void TampilDataMenuCari(){
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID MENU");
        model.addColumn("NAMA");
        model.addColumn("JENIS");
        model.addColumn("KATEGORI");
        model.addColumn("HARGA");
        
        try{
            String sql = "SELECT * FROM menu WHERE nama_menu='"+frm.jTextField3.getText()+"';";
            java.sql.Connection conn = Connector.configDB();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet res = stm.executeQuery(sql);
            
            while (res.next()){
                model.addRow(new Object[]{
                res.getString(1),
                res.getString(2),
                res.getString(3),
                res.getString(4),
                res.getString(5)});
            }
            frm.jTable1.setModel(model);
            
            
        }
        catch(SQLException e){
            System.out.println("Error "+e.getMessage());
        }
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if(ae.getSource()==frm.jButton2){
            KosongkanFormMenu();
            
        }else if(ae.getSource()==frm.jButton1){
            KosongkanFormMenu();
            
        }else if(ae.getSource()==frm.jButton3){
            data.setId(frm.jTextField1.getText());
            data.setNamaMenu(frm.jTextField2.getText());
            data.setJenisMenu((String) frm.jComboBox1.getSelectedItem());
            data.setKategori((String) frm.jComboBox2.getSelectedItem());
            data.setHarga(frm.jTextField5.getText());
            try{
                if(data.SimpanMenu(data)){
                    JOptionPane.showMessageDialog(null, "Simpan Data Sukses");
                    KosongkanFormMenu();
                    TampilDataMenu();
                }
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null, ex);
            }
            
        }else if(ae.getSource()==frm.jButton4){
            data.setId(frm.jTextField1.getText());
            data.setNamaMenu(frm.jTextField2.getText());
            data.setJenisMenu((String) frm.jComboBox1.getSelectedItem());
            data.setKategori((String) frm.jComboBox2.getSelectedItem());
            data.setHarga(frm.jTextField5.getText());
            try{
                if(data.UpdateMenu(data)){
                    JOptionPane.showMessageDialog(null, "Update Data Sukses");
                    KosongkanFormMenu();
                    TampilDataMenu();
                }
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null, ex);
            }
            
        }else if (ae.getSource()==frm.jButton5){
            data.setId(frm.jTextField1.getText());
            try{
                if(data.HapusMenu(data)){
                    JOptionPane.showMessageDialog(null, "Hapus Data Sukses");
                    KosongkanFormMenu();
                    TampilDataMenu();
                }
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null, ex);
            }
        }else if (ae.getSource()==frm.jButton6){
            frm.dispose();
        }else if (ae.getSource()==frm.jButton7){
            TampilDataMenuCari();
        }else if (ae.getSource()==frm.jButton8){
            TampilDataMenu();
        }
    }

    @Override
    public void mouseClicked(MouseEvent me) {
        if(me.getSource()==frm.jTable1){
            frm.jTextField1.setEditable(false);
            
            int baris = frm.jTable1.rowAtPoint(me.getPoint());
            String id = frm.jTable1.getValueAt(baris, 0).toString();
            frm.jTextField1.setText(id);
            String nama = frm.jTable1.getValueAt(baris, 1).toString();
            frm.jTextField2.setText(nama);
            String jenis = frm.jTable1.getValueAt(baris, 2).toString();
            frm.jComboBox1.setSelectedItem(jenis);
            String kategori = frm.jTable1.getValueAt(baris, 3).toString();
            frm.jComboBox2.setSelectedItem(kategori);
            String harga = frm.jTable1.getValueAt(baris, 4).toString();
            frm.jTextField5.setText(harga);
        }
    }

    @Override
    public void mousePressed(MouseEvent me) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseReleased(MouseEvent me) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseEntered(MouseEvent me) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseExited(MouseEvent me) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void dispose() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private String toString(int ID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
