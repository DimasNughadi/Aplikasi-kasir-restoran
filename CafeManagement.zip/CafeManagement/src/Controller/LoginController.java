package Controller;

import Model.Connector;
import Model.user;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import view.FrmLogin;
import view.FrmUtama;

public class LoginController implements ActionListener, MouseListener{
    private user data;
    private FrmLogin frm;
    
    public LoginController(user data, FrmLogin frm){
        this.data = data;
        this.frm = frm;
        this.frm.jButton1.addActionListener(this);
        this.frm.jButton2.addActionListener(this);
    }
    
    public void Reset(){
        frm.jTextField1.setText(null);
        frm.jPasswordField1.setText(null);
    }
    
    public void Cek(){
        try {
            String sql = "SELECT * FROM user WHERE username='"+frm.jTextField1.getText()+"' AND password='"+frm.jPasswordField1.getText()+"'";
            java.sql.Connection conn = Connector.configDB();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet res = stm.executeQuery(sql);
            if(res.next()){
                if(frm.jTextField1.getText().equals(res.getString("username")) && 
                        frm.jPasswordField1.getText().equals(res.getString("password"))){
                    JOptionPane.showMessageDialog(null, "Login Berhasil");
                    FrmUtama frm1 = new FrmUtama();
                    UtamaController ctrl = new UtamaController(frm1);
                    frm1.setVisible(true);
                    frm.dispose();
                }
            }else{
                    JOptionPane.showMessageDialog(null, "Username Atau Password Salah");
                    Reset();
                }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    @Override
    public void actionPerformed(ActionEvent ae) {
       if(ae.getSource()==frm.jButton1){
            Reset();
            
        }else if(ae.getSource()==frm.jButton2){
            Cek();
        }
    }

    @Override
    public void mouseClicked(MouseEvent me) {
        
    }

    @Override
    public void mousePressed(MouseEvent me) {
        
    }

    @Override
    public void mouseReleased(MouseEvent me) {
        
    }

    @Override
    public void mouseEntered(MouseEvent me) {
        
    }

    @Override
    public void mouseExited(MouseEvent me) {
        
    }
    
}
