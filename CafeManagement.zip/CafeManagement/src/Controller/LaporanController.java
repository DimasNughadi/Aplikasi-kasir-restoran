package Controller;

import Model.Connector;
import Model.Laporan;
import Model.Transaksi;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;
import view.FrmLaporan;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LaporanController implements ActionListener{
    private Laporan data;
    private Transaksi data2;
    private FrmLaporan frm;
    
    public LaporanController(Laporan data, FrmLaporan frm){
        this.data = data;
        this.frm = frm;
    }
    
    public void TampilDataLaporan(){
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID LAPORAN");
        model.addColumn("ID TRANSAKSI");
        model.addColumn("TANGGAL LAPOR");
        model.addColumn("STATUS");
        
        try{
            String sql = "SELECT * FROM laporan";
            java.sql.Connection conn = Connector.configDB();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet res = stm.executeQuery(sql);
            
            while (res.next()){
                model.addRow(new Object[]{
                res.getString(1),
                res.getString(2),
                res.getString(3),
                res.getString(4)});
            }
            frm.jTable1.setModel(model);
            
        }
        catch(SQLException e){
            System.out.println("Error "+e.getMessage());
        }
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        frm.dispose();
    }
}
