package Controller;

import Model.Connector;
import Model.Transaksi;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import view.FrmPrint;

public class PrintController implements ActionListener{
    private Transaksi data;
    private FrmPrint frm;
    
    public PrintController(Transaksi data, FrmPrint frm){
        this.data = data;
        this.frm = frm;
        this.frm.jButton1.addActionListener(this);
    }
    
    public void SetValue(){
        frm.jTextField2.setText("kasir");
    }
    
    public void TampilDataTransaksi(){
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("MENU");
        model.addColumn("HARGA 1");
        model.addColumn("JUMLAH PESAN");
        model.addColumn("HARGA TOTAL MENU");
        
        try{
            String sql = "SELECT * FROM transaksi INNER JOIN menu "
                    + "ON (menu.id_menu = transaksi.id_menu)";
            java.sql.Connection conn = Connector.configDB();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet res = stm.executeQuery(sql);
            
            while (res.next()){
                model.addRow(new Object[]{
                res.getString(9),
                res.getString(4),
                res.getString(5),
                res.getString(6)});
            }
            frm.jTable1.setModel(model);
            
            
        }
        catch(SQLException e){
            System.out.println("Error "+e.getMessage());
        }
    }
    
    public boolean HapusSemua(Transaksi data) throws SQLException{
        PreparedStatement pstm = null;
        Connection conn = (Connection)Connector.configDB();
        
        String sql = "DELETE FROM transaksi";
        
        try{
            pstm = conn.prepareStatement(sql);
            pstm.execute();
            return true;
        }catch(HeadlessException | SQLException e){
            System.out.println(e);
            return false;
        }
    }
    
    @Override
    public void actionPerformed(ActionEvent ae) {
        if(ae.getSource()==frm.jButton1){
            try {
                frm.dispose();
                HapusSemua(data);
                    
            } catch (SQLException ex) {
                Logger.getLogger(PrintController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
}
