package Controller;

import Model.Connector;
import Model.Laporan;
import Model.Meja;
import Model.Menu;
import Model.Transaksi;
import view.FrmTransaksi;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.sql.SQLException;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import view.FrmPrint;


public class TransaksiController implements ActionListener, MouseListener{
    private Transaksi data;
    private Meja data2;
    private Menu data3;
    private Laporan data4;
    private FrmTransaksi frm;
    String ID = UUID.randomUUID().toString();
    String total;
    String bayar;
    String kembalian;
    
    public TransaksiController(Transaksi data, FrmTransaksi frm, Meja data2, Menu data3, Laporan data4){
        this.data = data;
        this.data2 = data2;
        this.data3 = data3;
        this.data4 = data4;
        this.frm = frm;
        this.frm.jButton1.addActionListener(this);
        this.frm.jButton2.addActionListener(this);
        this.frm.jButton3.addActionListener(this);
        this.frm.jButton4.addActionListener(this);
        this.frm.jButton5.addActionListener(this);
        this.frm.jButton6.addActionListener(this);
        this.frm.jButton7.addActionListener(this);
        this.frm.jButton8.addActionListener(this);
        this.frm.jTable1.addMouseListener(this);
        this.frm.jTable3.addMouseListener(this);
    }
    
    public void KosongkanFormTransaksi(){
        frm.jTextField1.setText(ID);
        frm.jTextField1.setEditable(true);
        frm.jTextField2.setEditable(true);
        frm.jTextField3.setEditable(true);
        frm.jTextField4.setEditable(true);
        frm.jTextField5.setEditable(true);
        frm.jTextField9.setEditable(true);
        frm.jTextField10.setEditable(true);
        frm.jTextField11.setEditable(true);
        frm.jTextField12.setEditable(true);
        frm.jTextField2.setText(null);
        frm.jTextField3.setText(null);
        frm.jTextField4.setText(null);
        frm.jTextField5.setText(null);
        frm.jTextField9.setText(null);
        frm.jTextField10.setText(null);
        frm.jTextField11.setText(null);
        frm.jTextField12.setText(null);
        frm.jComboBox1.setSelectedIndex(0);
    }
    
    public void Next(){
        frm.jTextField1.setText(null);
        frm.jTextField1.setEditable(true);
        frm.jTextField2.setEditable(true);
        frm.jTextField3.setEditable(true);
        frm.jTextField4.setEditable(true);
        frm.jTextField5.setEditable(true);
        frm.jTextField9.setEditable(true);
        frm.jTextField10.setEditable(true);
        frm.jTextField11.setEditable(true);
        frm.jTextField12.setEditable(true);
        frm.jTextField2.setText(null);
        frm.jTextField3.setText(null);
        frm.jTextField4.setText(null);
        frm.jTextField5.setText(null);
        frm.jTextField9.setText(null);
        frm.jTextField10.setText(null);
        frm.jTextField11.setText(null);
        frm.jTextField12.setText(null);
        frm.jComboBox1.setSelectedIndex(0);
    }
    
    public void TambahPesanan(){
        frm.jTextField1.setEditable(false);
        frm.jTextField12.setEditable(false);
        frm.jComboBox1.setEditable(false);
        frm.jTextField2.setText(null);
        frm.jTextField3.setText(null);
        frm.jTextField4.setText(null);
        frm.jTextField5.setText(null);
        frm.jTextField9.setText(null);
        frm.jTextField10.setText(null);
        frm.jTextField11.setText(null);
    }
    
    public void TampilDataTransaksi(){
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID TRANSAKSI");
        model.addColumn("ID MEJA");
        model.addColumn("ID MENU");
        model.addColumn("Harga 1");
        model.addColumn("JUMLAH PESAN");
        model.addColumn("HARGA TOTAL MENU");
        model.addColumn("CUSTOMER");
        
        try{
            String sql = "SELECT * FROM transaksi";
            java.sql.Connection conn = Connector.configDB();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet res = stm.executeQuery(sql);
            
            while (res.next()){
                model.addRow(new Object[]{
                res.getString(1),
                res.getString(2),
                res.getString(3),
                res.getString(4),
                res.getString(5),
                res.getString(6),
                res.getString(7)});
            }
            frm.jTable1.setModel(model);
            
            
        }
        catch(SQLException e){
            System.out.println("Error "+e.getMessage());
        }
    }
    
    public void tampil_combo(){
        try {
            String sql = "select id_meja from meja where status='kosong'";    
            java.sql.Connection conn = Connector.configDB();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet res = stm.executeQuery(sql);                           
        
            while(res.next()){
                Object[] ob = new Object[3];
                ob[0] = res.getString(1);
                frm.jComboBox1.addItem((String) ob[0]);
            }
         
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }
    
    public void TampilDataMenuT(){
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID MENU");
        model.addColumn("NAMA");
        model.addColumn("JENIS");
        model.addColumn("KATEGORI");
        model.addColumn("HARGA");
        
        try{
            String sql = "SELECT * FROM menu";
            java.sql.Connection conn = Connector.configDB();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet res = stm.executeQuery(sql);
            
            while (res.next()){
                model.addRow(new Object[]{
                res.getString(1),
                res.getString(2),
                res.getString(3),
                res.getString(4),
                res.getString(5)});
            }
            frm.jTable3.setModel(model);
            
            
        }
        catch(SQLException e){
            System.out.println("Error "+e.getMessage());
        }
    }
    
    public void sum(){
        DefaultTableModel model = new DefaultTableModel();
        int jumlah = frm.jTable1.getRowCount();
        String harga = null;
        int hargafinal=0;
        
        for (int i = 0; i < jumlah; i++) {
            harga = frm.jTable1.getValueAt(i, 5).toString();
            hargafinal += Integer.parseInt(harga);
        }
        String hasil = String.valueOf(hargafinal);
        frm.jTextField9.setText(hasil);
    }

    
    @Override
    public void actionPerformed(ActionEvent ae) {
        if(ae.getSource()==frm.jButton2){
            TambahPesanan();
            
        }else if(ae.getSource()==frm.jButton1){
            KosongkanFormTransaksi();
            
        }else if(ae.getSource()==frm.jButton3){
            data.setIdT(frm.jTextField1.getText());
            data2.setId((String) frm.jComboBox1.getSelectedItem());
            data3.setId(frm.jTextField3.getText());
            data3.setHarga(frm.jTextField4.getText());
            data.setJmlPesan(frm.jTextField5.getText());
            data.setHargaT(frm.jTextField2.getText());
            data.setCus(frm.jTextField12.getText());
            try{
                if(data.SimpanTransaksi(data, data2, data3)){
                    JOptionPane.showMessageDialog(null, "Simpan Data Sukses");
                    TambahPesanan();
                    TampilDataTransaksi();
                }
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null, ex);
            }
            
        }else if(ae.getSource()==frm.jButton4){
            data.setIdT(frm.jTextField1.getText());
            data2.setId((String) frm.jComboBox1.getSelectedItem());
            data3.setId(frm.jTextField3.getText());
            data3.setHarga(frm.jTextField4.getText());
            data.setJmlPesan(frm.jTextField5.getText());
            data.setHargaT(frm.jTextField2.getText());
            data.setCus(frm.jTextField12.getText());
            try{
                if(data.UpdateTransaksi(data, data2, data3)){
                    JOptionPane.showMessageDialog(null, "Update Data Sukses");
                    KosongkanFormTransaksi();
                    TampilDataTransaksi();
                }
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null, ex);
            }
            
        }else if (ae.getSource()==frm.jButton5){
            data.setIdT(frm.jTextField1.getText());
            data3.setId(frm.jTextField3.getText());
            try{
                if(data.HapusTransaksi(data, data3)){
                    JOptionPane.showMessageDialog(null, "Hapus Data Sukses");
                    KosongkanFormTransaksi();
                    TampilDataTransaksi();
                }
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null, ex);
            }
        }else if (ae.getSource()==frm.jButton6){
            frm.dispose();
        }
        else if(ae.getSource()==frm.jButton7){
            data4.setIdL(frm.jTextField12.getText() + frm.jTextField6.getText());
            data.setIdT(frm.jTextField1.getText());
            data4.setTgl_lapor(frm.jTextField6.getText());
            try{
                if(data4.TambahLaporan(data, data4)){
                    JOptionPane.showMessageDialog(null, "Print Data Sukses");
                    total = frm.jTextField9.getText();
                    bayar = frm.jTextField10.getText();
                    kembalian = frm.jTextField11.getText();

                    Transaksi dataT = new Transaksi();
                    FrmPrint frmP = new FrmPrint(total, bayar, kembalian);
                    PrintController ctrl = new PrintController(dataT, frmP);
                    frmP.setVisible(true);
                    ctrl.TampilDataTransaksi();
                    ctrl.SetValue();
                    frm.dispose();
                }
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null, ex);
            }
        }
        else if(ae.getSource()==frm.jButton8){
            sum();
        }
    }
    @Override
    public void mouseClicked(MouseEvent me) {
        if(me.getSource()==frm.jTable1){
            frm.jTextField1.setEditable(false);
            frm.jTextField4.setEditable(false);
            frm.jTextField12.setEditable(false);
            frm.jTextField3.setEditable(false);
            
            int baris = frm.jTable1.rowAtPoint(me.getPoint());
            String id_transaksi = frm.jTable1.getValueAt(baris, 0).toString();
            frm.jTextField1.setText(id_transaksi);
            String id_meja = frm.jTable1.getValueAt(baris, 1).toString();
            frm.jComboBox1.setSelectedItem(id_meja);
            String id_menu = frm.jTable1.getValueAt(baris, 2).toString();
            frm.jTextField3.setText(id_menu);
            String harga = frm.jTable1.getValueAt(baris, 3).toString();
            frm.jTextField4.setText(harga);
            String jml_pesan = frm.jTable1.getValueAt(baris, 4).toString();
            frm.jTextField5.setText(jml_pesan);
            String hargatotal = frm.jTable1.getValueAt(baris, 5).toString();
            frm.jTextField2.setText(hargatotal);
            String customer = frm.jTable1.getValueAt(baris, 6).toString();
            frm.jTextField12.setText(customer);
        }
        
    }

    @Override
    public void mousePressed(MouseEvent me) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseReleased(MouseEvent me) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseEntered(MouseEvent me) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseExited(MouseEvent me) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
