package Controller;

import Model.Meja;
import Model.Menu;
import Model.Transaksi;
import Model.Laporan;
import Model.user;
import view.FrmMeja;
import view.FrmMenu;
import view.FrmTransaksi;
import view.FrmUtama;
import view.FrmLaporan;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.FrmLogin;


public class UtamaController implements ActionListener{
    private FrmUtama frm;
    
    public UtamaController(FrmUtama frm){
        this.frm = frm;
        this.frm.jButton1.addActionListener(this);
        this.frm.jButton2.addActionListener(this);
        this.frm.jButton3.addActionListener(this);
        this.frm.jButton4.addActionListener(this);
        this.frm.jButton5.addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent ae) {
        if(ae.getSource()==frm.jButton1){
            Meja data = new Meja();
            FrmMeja frmM = new FrmMeja();
            MejaController ctrl = new MejaController(data, frmM);
        
            ctrl.KosongkanFormMeja();
            ctrl.TampilDataMeja();
            frmM.setVisible(true);
        }
        else if(ae.getSource()==frm.jButton2){
            Menu data = new Menu();
            FrmMenu frmMe = new FrmMenu();
            MenuController ctrl = new MenuController(data, frmMe);
        
            ctrl.KosongkanFormMenu();
            ctrl.TampilDataMenu();
            frmMe.setVisible(true);

        }
        else if(ae.getSource()==frm.jButton3){
            Transaksi data = new Transaksi();
            Meja data2 = new Meja();
            Menu data3 = new Menu();
            Laporan data4 = new Laporan();
            FrmTransaksi frmT = new FrmTransaksi();
            TransaksiController ctrl = new TransaksiController(data, frmT, data2, data3, data4);
        
            ctrl.KosongkanFormTransaksi();
            ctrl.TampilDataTransaksi();
            ctrl.tampil_combo();
            ctrl.TampilDataMenuT();
            frmT.setVisible(true);
        }
        else if(ae.getSource()==frm.jButton4){
            user data = new user();
            FrmLogin frm1 = new FrmLogin();
            LoginController ctrl = new LoginController(data, frm1);
            frm1.setVisible(true);
            frm.dispose();
        }
        else if (ae.getSource()==frm.jButton5){
            Laporan data = new Laporan();
            FrmLaporan frmL = new FrmLaporan();
            LaporanController ctrl = new LaporanController(data, frmL);
        
            ctrl.TampilDataLaporan();
            frmL.setVisible(true);
        }
    }
}
