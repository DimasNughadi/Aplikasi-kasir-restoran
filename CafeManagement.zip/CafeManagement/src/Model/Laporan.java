package Model;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Laporan extends Connector{
    private String id_laporan;
    private String tgl_lapor;
    private String status;
    
    public void setIdL(String id_laporan){
        this.id_laporan = id_laporan;
    }
    public String getIdL(){
        return id_laporan;
    }
    
    public void setTgl_lapor(String tgl_lapor){
        this.tgl_lapor = tgl_lapor;
    }
    public String getTgl_lapor(){
        return tgl_lapor;
    }
    
    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return status;
    }
    
    public boolean TambahLaporan (Transaksi data, Laporan data4) throws SQLException{
        PreparedStatement pstm = null;
        Connection conn = (Connection)Connector.configDB();
        
        String sql = "INSERT INTO laporan(id_laporan, id_transaksi, tgl_transaksi, status) "
                + "VALUES (?,?,?,'LUNAS')";
        
        try{
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, data4.getIdL());
            pstm.setString(2, data.getIdT());
            pstm.setString(3, data4.getTgl_lapor());
            pstm.execute();
            return true;
        }catch(HeadlessException | SQLException e){
            System.out.println(e);
            return false;
        }
    }
}
