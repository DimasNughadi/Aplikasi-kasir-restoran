package Model;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Menu extends Connector{
    private String id_menu;
    private String nama_menu;
    private String jenis_menu;
    private String kategori;
    private String harga;
    
    public void setId(String id_menu){
        this.id_menu = id_menu;
    }
    public String getId(){
        return id_menu;
    }
    
    public void setNamaMenu(String nama_menu){
        this.nama_menu = nama_menu;
    }
    public String getNamaMenu(){
        return nama_menu;
    }
    
    public void setJenisMenu(String jenis_menu){
        this.jenis_menu = jenis_menu;
    }
    public String getJenisMenu(){
        return jenis_menu;
    }
    
    public void setKategori(String kategori){
        this.kategori = kategori;
    }
    public String getKategori(){
        return kategori;
    }
    
    public void setHarga(String harga){
        this.harga = harga;
    }
    public String getHarga(){
        return harga;
    }
    
    public boolean SimpanMenu(Menu data) throws SQLException{
        PreparedStatement pstm = null;
        Connection conn = (Connection)Connector.configDB();
        
        String sql = "INSERT INTO menu (id_menu, nama_menu, jenis_menu, kategori, harga )"
                + "VALUES (?,?,?,?,?)";
        
        try{
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, data.getId());
            pstm.setString(2, data.getNamaMenu());
            pstm.setString(3, data.getJenisMenu());
            pstm.setString(4, data.getKategori());
            pstm.setString(5, data.getHarga());
            pstm.execute();
            return true;
        }catch(HeadlessException | SQLException e){
            System.out.println(e);
            return false;
        }
    }
    
    public boolean UpdateMenu(Menu data) throws SQLException{
        PreparedStatement pstm = null;
        Connection conn = (Connection)Connector.configDB();
        
        String sql = "UPDATE menu SET id_menu=?, nama_menu=?, jenis_menu=?, kategori=?,"
                + "harga=? WHERE id_menu=?;";
        
        try{
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, data.getId());
            pstm.setString(2, data.getNamaMenu());
            pstm.setString(3, data.getJenisMenu());
            pstm.setString(4, data.getKategori());
            pstm.setString(5, data.getHarga());
            pstm.setString(6, data.getId());
            pstm.execute();
            return true;
        }catch(HeadlessException | SQLException e){
            System.out.println(e);
            return false;
        }
    }
    
    public boolean HapusMenu(Menu data) throws SQLException{
        PreparedStatement pstm = null;
        Connection conn = (Connection)Connector.configDB();
        
        String sql = "DELETE FROM menu WHERE id_menu=?";
        
        try{
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, data.getId());
            pstm.execute();
            return true;
        }catch(HeadlessException | SQLException e){
            System.out.println(e);
            return false;
        }
    }
       
}
